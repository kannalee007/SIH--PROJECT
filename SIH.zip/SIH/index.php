<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>BUS BEACON | Member Portal</title>
    <link
      href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&display=swap"
      rel="stylesheet"
    />
    <style>
      :root {
        --chocolate-dark: #3a1f0a;
        --chocolate-medium: #6b4423;
        --chocolate-light: #d4a373;
        --gold-accent: #d4af37;
        --lux-purple: #5d3fd3;
        --lux-blue: #34ace0;
        --cream: #f8f4e9;
        --dark-bg: #1a2a3a;
        --dark-text: #e0e0e0;
        --accent-blue: #34ace0;
        --light-grey: #a0b0c0;
      }

      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      body {
        font-family: "Playfair Display", serif;
        background: url("bg.login.png") center/cover no-repeat fixed;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        overflow-x: hidden;
        position: relative;
        padding: 20px;
      }

      body::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(
          135deg,
          rgba(26, 42, 58, 0.8) 0%,
          rgba(52, 172, 224, 0.5) 100%
        );
        z-index: -1;
      }

      .main-heading {
        color: var(--dark-text);
        font-size: 2.5rem;
        margin-bottom: 30px;
        text-align: center;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        width: 100%;
        padding: 0 20px;
      }

      .container {
        width: 1000px;
        max-width: 100%;
        height: 650px;
        display: flex;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        position: relative;
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.2);
      }

      .form-container {
        width: 60%;
        padding: 60px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        transition: all 0.8s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        position: relative;
        overflow: hidden;
      }

      .login-container {
        background: rgba(35, 45, 60, 0.9);
      }

      .register-container {
        background: rgba(52, 172, 224, 0.85);
        transform: translateX(100%);
        position: absolute;
        right: 0;
        height: 100%;
        width: 60%;
        transition: all 0.8s cubic-bezier(0.68, -0.55, 0.265, 1.55);
      }

      .container.active .login-container {
        transform: translateX(-100%);
      }

      .container.active .register-container {
        transform: translateX(0);
        right: auto;
        left: 0;
      }

      .form-title {
        font-size: 2.5rem;
        margin-bottom: 30px;
        color: var(--dark-text);
        position: relative;
        display: inline-block;
        width: 100%;
        text-align: center;
      }

      .form-title::after {
        content: "";
        position: absolute;
        bottom: -10px;
        left: 50%;
        transform: translateX(-50%);
        width: 60px;
        height: 3px;
        background: var(--accent-blue);
      }

      .register-container .form-title {
        color: var(--dark-text);
      }

      .register-container .form-title::after {
        background: var(--dark-text);
      }

      .form-group {
        margin-bottom: 25px;
        position: relative;
        width: 100%;
      }

      .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: var(--light-grey);
        transition: all 0.3s;
      }

      .register-container .form-group label {
        color: var(--dark-text);
      }

      .form-control {
        width: 100%;
        padding: 15px;
        border: none;
        border-bottom: 2px solid rgba(255, 255, 255, 0.3);
        background: transparent;
        font-size: 16px;
        transition: all 0.3s;
        color: var(--dark-text);
      }

      .form-control:focus {
        outline: none;
        border-bottom-color: var(--accent-blue);
      }

      .register-container .form-control {
        border-bottom-color: rgba(255, 255, 255, 0.5);
        color: var(--dark-text);
      }

      .register-container .form-control:focus {
        border-bottom-color: var(--dark-text);
      }

      .form-control::placeholder {
        color: rgba(255, 255, 255, 0.6);
      }

      .register-container .form-control::placeholder {
        color: rgba(255, 255, 255, 0.7);
      }

      .btn {
        padding: 15px 30px;
        border: none;
        border-radius: 30px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        margin-top: 10px;
        text-transform: uppercase;
        letter-spacing: 1px;
        display: block;
        width: 100%;
        max-width: 200px;
        margin: 20px auto 0;
      }

      .btn-primary {
        background: var(--accent-blue);
        color: var(--dark-text);
        box-shadow: 0 4px 15px rgba(52, 172, 224, 0.3);
      }

      .btn-primary:hover {
        background: #2a94cc;
        transform: translateY(-3px);
        box-shadow: 0 6px 20px rgba(52, 172, 224, 0.4);
      }

      .register-container .btn-primary {
        background: var(--dark-bg);
        box-shadow: 0 4px 15px rgba(26, 42, 58, 0.3);
      }

      .register-container .btn-primary:hover {
        background: #3a506a;
        box-shadow: 0 6px 20px rgba(26, 42, 58, 0.4);
      }

      .toggle-form {
        margin-top: 20px;
        text-align: center;
        color: var(--light-grey);
        width: 100%;
      }

      .toggle-btn {
        background: none;
        border: none;
        color: var(--accent-blue);
        font-weight: 600;
        cursor: pointer;
        text-decoration: underline;
        transition: all 0.3s;
        font-size: 15px;
      }

      .toggle-btn:hover {
        color: var(--dark-text);
      }

      .register-container .toggle-btn {
        color: var(--dark-text);
      }

      .register-container .toggle-btn:hover {
        color: #e0e0e0;
      }

      .gallery-side {
        width: 40%;
        position: relative;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 0;
      }

      .brand-display {
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 0;
      }

      /* Error message styling */
      .error-message {
        color: #ff6b6b;
        font-size: 14px;
        margin-top: 5px;
        text-align: center;
        padding: 8px;
        background: rgba(255, 107, 107, 0.1);
        border-radius: 4px;
        margin-bottom: 10px;
      }
      
      .success-message {
        color: #51cf66;
        font-size: 14px;
        margin-top: 5px;
        text-align: center;
        padding: 8px;
        background: rgba(81, 207, 102, 0.1);
        border-radius: 4px;
        margin-bottom: 10px;
      }

      @media (max-width: 1200px) {
        .container {
          width: 900px;
          height: 600px;
        }

        .main-heading {
          font-size: 2rem;
        }
      }

      @media (max-width: 992px) {
        .container {
          width: 700px;
          height: 500px;
        }

        .form-container {
          padding: 40px;
        }
      }

      @media (max-width: 768px) {
        .main-heading {
          font-size: 1.8rem;
          margin-bottom: 20px;
        }

        .container {
          flex-direction: column;
          height: auto;
          width: 100%;
          max-width: 500px;
        }

        .form-container,
        .gallery-side {
          width: 100%;
        }

        .form-container {
          padding: 40px 30px;
        }

        .register-container {
          width: 100%;
        }

        .gallery-side {
          height: 150px;
          flex-direction: row;
          padding: 20px;
          align-items: center;
        }

        .brand-display {
          flex-direction: row;
          justify-content: center;
          gap: 20px;
        }

        .brand-name {
          font-size: 1.2rem;
        }

        .brand-tagline {
          font-size: 0.7rem;
        }

        .form-title {
          font-size: 2rem;
        }

        .btn {
          max-width: 150px;
        }
      }

      @media (max-width: 480px) {
        .main-heading {
          font-size: 1.5rem;
        }

        .form-title {
          font-size: 1.8rem;
        }

        .brand-name {
          font-size: 1rem;
        }
      }
    </style>
  </head>
  <body>
    <h1 class="main-heading">BUS BEACON</h1>

    <div class="container" id="container">
      <div class="form-container login-container">
        <h2 class="form-title">Welcome Back</h2>
        <?php
        if (isset($_SESSION['login_errors']) && !empty($_SESSION['login_errors'])) {
            foreach ($_SESSION['login_errors'] as $error) {
                echo "<div class='error-message'>$error</div>";
            }
            unset($_SESSION['login_errors']);
        }
        ?>
        <form id="loginForm" action="login.php" method="POST">
          <div class="form-group">
            <label for="login-email">Email</label>
            <input
              type="email"
              id="login-email"
              name="email"
              class="form-control"
              placeholder="Your email"
              value="<?php echo isset($_SESSION['login_form_data']['email']) ? htmlspecialchars($_SESSION['login_form_data']['email']) : ''; ?>"
              required
            />
          </div>
          <div class="form-group">
            <label for="login-password">Password</label>
            <input
              type="password"
              id="login-password"
              name="password"
              class="form-control"
              placeholder="Your password"
              required
            />
          </div>
          <button type="submit" class="btn btn-primary">Sign In</button>
        </form>
        <div class="toggle-form">
          <span>New to our world? </span>
          <button class="toggle-btn" id="show-register">
            Create an account
          </button>
        </div>
      </div>

      <div class="form-container register-container">
        <h2 class="form-title">Join Us</h2>
        <?php
        if (isset($_SESSION['register_success'])) {
            echo "<div class='success-message'>" . $_SESSION['register_success'] . "</div>";
            unset($_SESSION['register_success']);
        }
        if (isset($_SESSION['register_errors']) && !empty($_SESSION['register_errors'])) {
            foreach ($_SESSION['register_errors'] as $error) {
                echo "<div class='error-message'>$error</div>";
            }
            unset($_SESSION['register_errors']);
        }
        ?>
        <form id="registerForm" action="register.php" method="POST">
          <div class="form-group">
            <label for="register-name">Full Name</label>
            <input
              type="text"
              id="register-name"
              name="name"
              class="form-control"
              placeholder="Your name"
              value="<?php echo isset($_SESSION['register_form_data']['name']) ? htmlspecialchars($_SESSION['register_form_data']['name']) : ''; ?>"
              required
            />
          </div>
          <div class="form-group">
            <label for="register-email">Email</label>
            <input
              type="email"
              id="register-email"
              name="email"
              class="form-control"
              placeholder="Your email"
              value="<?php echo isset($_SESSION['register_form_data']['email']) ? htmlspecialchars($_SESSION['register_form_data']['email']) : ''; ?>"
              required
            />
          </div>
          <div class="form-group">
            <label for="register-password">Password</label>
            <input
              type="password"
              id="register-password"
              name="password"
              class="form-control"
              placeholder="Create password"
              required
            />
          </div>
          <button type="submit" class="btn btn-primary">Register</button>
        </form>
        <div class="toggle-form">
          <span>Already a member? </span>
          <button class="toggle-btn" id="show-login">Sign in</button>
        </div>
      </div>

      <div
        class="gallery-side"
        style="
          background: var(--dark-bg);
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          padding: 0;
        "
      >
        <div
          class="brand-display"
          style="
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 0;
          "
        >
          <img
            src="ph.bg.png"
            alt="BUS BEACON Logo"
            style="
              width: 100%;
              height: 100%;
              object-fit: cover;
              border-radius: 0;
              margin-bottom: 0;
              display: block;
            "
          />
        </div>
      </div>
    </div>

    <script>
      const container = document.getElementById("container");
      const showRegister = document.getElementById("show-register");
      const showLogin = document.getElementById("show-login");

      showRegister.addEventListener("click", () => {
        container.classList.add("active");
      });

      showLogin.addEventListener("click", () => {
        container.classList.remove("active");
      });

      // Auto-switch to register form if there are registration errors
      <?php if (isset($_SESSION['register_errors']) && !empty($_SESSION['register_errors'])): ?>
        container.classList.add("active");
      <?php endif; ?>
    </script>
  </body>
</html>
<?php
// Clear form data after displaying it
if (isset($_SESSION['login_form_data'])) {
    unset($_SESSION['login_form_data']);
}
if (isset($_SESSION['register_form_data'])) {
    unset($_SESSION['register_form_data']);
}
?>